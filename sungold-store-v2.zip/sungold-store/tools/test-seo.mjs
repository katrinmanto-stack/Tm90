// تست تحلیل سئو: node tools/test-seo.mjs
import assert from 'node:assert/strict';
import { norm, analyze, suggest, clip, len } from '../app/js/seo.js';

let n = 0; const t = (name, fn) => { fn(); n++; console.log('ok', name); };
const lvl = (res, id) => (res.items.find((i) => i.id === id) || {}).level;

t('norm: ی/ک عربی، نیم‌فاصله و ارقام', () => {
  assert.equal(norm('شال‌گردن'), 'شال گردن');
  assert.equal(norm('كتاب ياسمين'), 'کتاب یاسمین');
  assert.equal(norm('مدل ۱۲۳ و ٤٥٦'), 'مدل 123 و 456');
});
t('clip: کوتاه‌کردن در مرز کلمه', () => {
  const s = clip('این یک متن نسبتاً طولانی برای آزمایش کوتاه کردن در مرز کلمه است', 30);
  assert.ok(len(s) <= 30 && s.endsWith('…'), s);
});
const good = {
  name: 'مانتو کتان سبک', slug: encodeURIComponent('مانتو-کتان-سبک'),
  short_description: 'مانتو کتان سبک و خنک مخصوص تابستان با دوخت تمیز.',
  description: ('مانتو کتان سبک و خنک برای روزهای گرم. ' + 'جنس پارچه نرم و مقاوم است و شست‌وشو آسان دارد. '.repeat(20)),
  image: { id: 1, alt: 'مانتو کتان' }, gallery: [{ id: 2, alt: 'پشت مانتو' }],
  seo: { title: 'مانتو کتان سبک تابستانی | فروشگاه', desc: 'خرید آنلاین مانتو کتان سبک و خنک تابستانی با دوخت تمیز و رنگ‌بندی متنوع؛ مناسب محل کار و رفت‌وآمد روزمره.', kw: 'مانتو کتان', noindex: false },
};
t('محصول کامل: امتیاز بالا و بدون مورد «bad»', () => {
  const r = analyze(good, { siteName: 'فروشگاه' });
  assert.ok(r.score >= 90, 'score=' + r.score);
  assert.equal(r.grade, 'good');
  assert.ok(!r.items.some((i) => i.level === 'bad'), JSON.stringify(r.items.filter((i) => i.level === 'bad')));
});
t('محصول خالی: امتیاز ضعیف', () => {
  const r = analyze({ name: 'x', slug: '', description: '', short_description: '', image: { id: 0 }, gallery: [], seo: {} });
  assert.equal(r.grade, 'bad');
  assert.equal(lvl(r, 'kw'), 'bad'); assert.equal(lvl(r, 'desc'), 'bad'); assert.equal(lvl(r, 'image'), 'bad');
});
t('کلمه‌ی کلیدی نبودن در عنوان', () => {
  const r = analyze({ ...good, seo: { ...good.seo, kw: 'شلوار' } });
  assert.equal(lvl(r, 'kw_title'), 'bad'); assert.equal(lvl(r, 'kw_slug'), 'warn');
});
t('تطبیق کلمه‌ی کلیدی با ی/ک عربی و نیم‌فاصله', () => {
  const r = analyze({ ...good, seo: { ...good.seo, kw: 'مانتو كتان' } });
  assert.equal(lvl(r, 'kw_title'), 'ok');
});
t('alt: همه / بعضی / اصلی خالی', () => {
  assert.equal(lvl(analyze(good), 'alt'), 'ok');
  assert.equal(lvl(analyze({ ...good, gallery: [{ id: 2, alt: '' }] }), 'alt'), 'warn');
  assert.equal(lvl(analyze({ ...good, image: { id: 1, alt: '' } }), 'alt'), 'bad');
});
t('طول عنوان و توضیح: مرزها', () => {
  const mk = (title, desc) => analyze({ ...good, seo: { ...good.seo, title, desc } });
  assert.equal(lvl(mk('ا'.repeat(30), 'ب'.repeat(120)), 'title'), 'ok');
  assert.equal(lvl(mk('ا'.repeat(61), 'ب'.repeat(161)), 'title'), 'warn');
  assert.equal(lvl(mk('ا'.repeat(61), 'ب'.repeat(161)), 'desc'), 'warn');
  assert.equal(lvl(mk('ا'.repeat(80), 'ب'.repeat(300)), 'title'), 'bad');
  assert.equal(lvl(mk('ا'.repeat(80), 'ب'.repeat(300)), 'desc'), 'bad');
});
t('noindex به‌عنوان مشکل گزارش می‌شود', () => {
  assert.equal(lvl(analyze({ ...good, seo: { ...good.seo, noindex: true } }), 'noindex'), 'bad');
});
t('editable=false: بررسی‌های عنوان/متا/کلمه‌ی کلیدی حذف می‌شود', () => {
  const r = analyze({ ...good, seo: {} }, { editable: false });
  assert.ok(!r.items.some((i) => ['title', 'desc', 'kw'].includes(i.id)));
});
t('suggest: عنوان ≤۶۰ و توضیح ≤۱۵۵', () => {
  const s = suggest(good, 'فروشگاه');
  assert.ok(len(s.title) <= 60 && s.title.includes('مانتو') && len(s.desc) <= 155 && s.desc.length > 20, JSON.stringify(s));
  const e = suggest({ name: 'کیف چرمی', short_description: '', description: '' }, 'فروشگاه');
  assert.ok(e.desc.includes('کیف چرمی'));
});
console.log(`\n${n} tests passed`);
