const P = {
  text: 'M4 6h16M12 6v14M8 20h8',
  store: 'M3 9l2-5h14l2 5M3 9h18M5 9v11h14V9M10 20v-6h4v6',
  palette: 'M12 3a9 9 0 1 0 0 18c1.2 0 2-.8 2-1.8 0-1-.8-1.4-.8-2.2 0-.8.7-1.4 1.6-1.4H17a4 4 0 0 0 4-4c0-4.4-4-8.6-9-8.6zM7.5 11h.01M10 7.5h.01M14.5 7.5h.01',
  layout: 'M3 4h18v16H3zM3 9h18M9 9v11',
  home: 'M3 11l9-8 9 8v10h-6v-6H9v6H3z',
  bag: 'M6 8h12l1 13H5zM9 8V6a3 3 0 0 1 6 0v2',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
  gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
  box: 'M3 8l9-5 9 5v8l-9 5-9-5zM3 8l9 5 9-5M12 13v8',
  search: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-5-5',
  back: 'M9 6l6 6-6 6',
  wand: 'M5 19L19 5M14 4l.5 2L17 6.5 14.5 7 14 9l-.5-2L11 6.5 13.5 6zM18 12l.4 1.6 1.6.4-1.6.4L18 16l-.4-1.6L16 14l1.6-.4z',
  up: 'M6 15l6-6 6 6', down: 'M6 9l6 6 6-6', plus: 'M12 5v14M5 12h14', minus: 'M5 12h14',
  trash: 'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3',
  image: 'M3 5h18v14H3zM3 16l5-5 4 4 3-3 6 6M9 9.5h.01',
  close: 'M6 6l12 12M18 6L6 18', check: 'M5 12l5 5 9-10',
  refresh: 'M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7',
  external: 'M14 4h6v6M20 4l-9 9M18 14v6H4V6h6',
  monitor: 'M3 4h18v12H3zM8 20h8M12 16v4', phone: 'M7 2h10v20H7zM11 18h2',
  logout: 'M9 4H4v16h5M16 8l4 4-4 4M20 12H9', undo: 'M3 7v6h6M3 13a9 9 0 1 0 3-7',
  receipt: 'M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6M9 16h3',
  call: 'M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z',
  chat: 'M4 5h16v11H9l-5 4z', copy: 'M9 9h11v11H9zM5 15H4V4h11v1', truck: 'M1 6h13v10H1zM14 9h5l3 3v4h-8M6 19a2 2 0 1 0 .01 0M18 19a2 2 0 1 0 .01 0',
  send: 'M4 12l16-8-6 16-3-6z', pin: 'M12 21s7-6 7-11a7 7 0 1 0-14 0c0 5 7 11 7 11zM12 12a2 2 0 1 0 0-4 2 2 0 0 0 0 4z',
  card: 'M3 6h18v12H3zM3 10h18M7 15h4', note: 'M5 3h14v18H5zM9 8h6M9 12h6M9 16h3',
  download: 'M12 3v12M7 10l5 5 5-5M4 20h16', alert: 'M12 3l10 18H2zM12 10v4M12 17.5h.01',
};
export function icon(name, size = 22) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', size); s.setAttribute('height', size);
  s.setAttribute('aria-hidden', 'true'); s.setAttribute('class', 'ic');
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  p.setAttribute('d', P[name] || ''); s.append(p); return s;
}
